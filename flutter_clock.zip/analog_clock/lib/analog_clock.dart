import 'dart:async';

import 'package:analog_clock/digital_clock.dart';
import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart' show radians;

import 'container_hand.dart';

final radiansPerTick = radians(360 / 60);
final radiansPerHour = radians(360 / 12);

class AnalogClock extends StatefulWidget {
  const AnalogClock(this.model);

  final ClockModel model;

  @override
  _AnalogClockState createState() => _AnalogClockState();
}

class _AnalogClockState extends State<AnalogClock> {
  var _now = DateTime.now();

  Timer _timer;

  @override
  void initState() {
    super.initState();

    _updateTime();
  }

  void _updateTime() {
    setState(() {
      _now = DateTime.now();
      _timer = Timer(
        Duration(seconds: 1) - Duration(milliseconds: _now.millisecond),
        _updateTime,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final time = DateFormat.Hms().format(DateTime.now());

    Widget _circularContainer(
        double height, double width, Color color, double right) {
      return new Positioned(
        left: 0,
        top: 0,
        bottom: 0,
        right: right,
        child: Center(
          child: Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
              border: Border.all(color: color),
              borderRadius: BorderRadius.circular(200),
            ),
          ),
        ),
      );
    }

    return Semantics.fromProperties(
      properties: SemanticsProperties(
        label: 'Analog clock with time $time',
        value: time,
      ),
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/BG.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                padding: const EdgeInsets.all(15),
                width:
                    MediaQuery.of(context).orientation == Orientation.landscape
                        ? 265
                        : 150,
                height: double.infinity,
                child: DigitalClock(),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? 240
                  : 160,
              child: ContainerHand(
                color: Colors.transparent,
                size: 0.5,
                angleRadians: _now.hour * radiansPerHour +
                    (_now.minute / 60) * radiansPerHour,
                child: Transform.translate(
                  offset: Offset(0.0, -65.0),
                  child: Container(
                    width: 20,
                    height: MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? 150
                        : 110,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.circular(100),
                      color: Color.fromRGBO(244, 196, 48, 10),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 0,
              left: 0,
              bottom: 0,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? 240
                  : 160,
              child: ContainerHand(
                color: Colors.transparent,
                size: 0.5,
                angleRadians: _now.minute * radiansPerTick,
                child: Transform.translate(
                  offset: Offset(
                      0.0,
                      MediaQuery.of(context).orientation ==
                              Orientation.landscape
                          ? -135.0
                          : -85.0),
                  child: Container(
                    width: 15,
                    height: MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? 250
                        : 150,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.circular(100),
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? 240
                  : 160,
              child: ContainerHand(
                color: Colors.transparent,
                size: 0.5,
                angleRadians: _now.second * radiansPerTick,
                child: Transform.translate(
                  offset: Offset(
                      0.0,
                      MediaQuery.of(context).orientation ==
                              Orientation.landscape
                          ? -160.0
                          : -107.0),
                  child: Container(
                    width: 5,
                    height: MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? 300
                        : 200,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.circular(100),
                      color: Colors.green,
                    ),
                  ),
                ),
              ),
            ),
            MediaQuery.of(context).orientation == Orientation.landscape
                ? _circularContainer(320, 320, Colors.white, 240)
                : _circularContainer(320, 320, Colors.white, 160),
            MediaQuery.of(context).orientation == Orientation.landscape
                ? _circularContainer(10, 10, Colors.cyan, 240)
                : _circularContainer(10, 10, Colors.cyan, 160),
          ],
        ),
      ),
    );
  }
}
