# Analog Clock

This app is my submission for Flutter Clock Challenge.
It has a light theme and a dark theme.It shows time in both analog as well as digital format.

<img src='dark.png' width='350'>

<img src='light.png' width='350'>
